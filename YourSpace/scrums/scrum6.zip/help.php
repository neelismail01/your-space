<!DOCTYPE html>
<html>
  <head>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <title>Help</title>

    <style>

        nav {
          background-color:#ff0000;
          height:80px;
          position:fixed;
          margin-bottom:5px;
          z-index:100;
        }

        #logo {
          width:80px;
          height:80px;
          margin-right:25px;
          margin-top:10px;
        }

        .body {
          margin:auto;
          width:70%;
        }

        #make-account {
          margin-top:75px;
        }

    </style>
  </head>
  <body style="background-color:#fcfcfc">

        <nav>
          <div class="nav-wrapper">
            <a href="edit.php" class="brand-logo center" style="margin-top:-6px"><h3>Twitter</h3></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a href="about.php">About</a></li>
                <li><a href="help.php">Help</a></li>
            </ul>
            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li><a href="edit.php">My Account</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
          </div>
        </nav>
      
    <br>

    <div id="make-account" class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content black-text">
              <span class="card-title"><strong>How to make an account:</strong></span>
              <ol>
                <li>Find the "Register" tab in the navigation bar, and click it.</li>
                <li>Once on the "Register" page, follow the prompts in the form, and enter an email address, a username, and a password.</li>
                <li>Click on the "Register" button below the form.</li>
                <li>That's it! Now you have made an account. See below to learn how to sign in to your new account.</li>
              </ol>
            </div>
          </div>
        </div>
    </div>

    <div class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content black-text">
              <span class="card-title"><strong>How to sign in:</strong></span>
              <ol>
                <li>On the register page, click on the "sign in" link below the "Register" button to get to the sign in page.</li>
                <li>Once on the "Sign in" page, enter your username and password into the form, and click the "Log in" button.</li>
                <li>There you have it! You are now logged into your account.</li>
              </ol>
            </div>
          </div>
        </div>
    </div>

    <div class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content black-text">
              <span class="card-title"><strong>How to tweet a message:</strong></span>
              <ol>
                <li>To be able to tweet, you first have to be in your account. If you are not, see the above instructions on how to log in to your account.</li>
                <li>If you are in your account, to tweet a message, you simply have to enter text into the box located on the left of the page.</li>
                <li>To tweet your message to the public, simply click the "Tweet" message found below the box.</li>
                <li>That it! You have now tweeted a message.</li>
              </ol>
            </div>
          </div>
        </div>
    </div>

    <div class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content black-text">
              <span class="card-title"><strong>How to search tweets:</strong></span>
              <ol>
                <li>On this site, you can search for tweets made by particular users, keywords in tweets, or hashtags.</li>
                <li>To do so, you simply have to type in the desired username, keyword, or hashtag into the search bar found on the left of the page.</li>
                <li>You will then be directed to a search page, and your search results will be displayed.</li>
                <li>That's all you have to do to search on this site!</li>
              </ol>
            </div>
          </div>
        </div>
    </div>

  <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

  </body>
</html>