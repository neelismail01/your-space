<!DOCTYPE html>
<html>
	<head>
		<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <title>Our Version of Twitter</title>

    <style>

        .body {
          margin:auto;
        }

        nav {
          background-color:#ff0000;
          width:96.25%;
          height:130px;
          position:fixed;
          margin-bottom:5px;
          margin-top:-35px;
          z-index:100;
        }

        .page-footer {
          background-color:#ff0000;
          clear:both;
        }

        #welcome {
          margin-top:85px;
          text-align: center;
          width:70%%;
        }

        #logo {
          width:100px;
          height:100px;
          margin:15px;
        }

        #box {
          background-color:#fffcfc;
        }

        #make-tweet {
          width:49.5%;
          float:left;
          padding-left:10px;
          margin-top:-10px;
        }

        #tweet-history {
          width:49.5%;
          height:150px;
          float:right;
          padding-right:10px;
          margin-top:-10px;
        }

    </style>
	</head>
	<body class="card-panel white">

    <div id="box">

    <nav>
      <div class="nav-wrapper">
        <a href="#" class="brand-logo center"><h1><strong>Twitter</strong></h1></a>
        <ul id="nav-mobile" class="left hide-on-med-and-down">
          <li><a href="logout.php">Logout</a></li>
          <li><a href="register.php">Register</a></li>
        </ul>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
          <li><img id="logo" src="twitter-logo-orange.png" /></li>
        </ul>
      </div>
    </nav>
    	
    <br>

    <div id="welcome" class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content white-text">
            	<span class="card-title">
            <?php
						// pass in some info;
						require("common.php"); 
		
						if(empty($_SESSION['user'])) { 
  
							// If they are not, we redirect them to the login page. 
							$location = "http://" . $_SERVER['HTTP_HOST'] . "/login.php";
							echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
							//exit;
         
        					// Remember that this die statement is absolutely critical.  Without it, 
        					// people can view your members-only content without logging in. 
        					die("Redirecting to login.php"); 
    					}
		
						// To access $_SESSION['user'] values put in an array, show user his username
						$arr = array_values($_SESSION['user']);
						echo "<h4 style='color:black'><strong>Welcome, " . $arr[1] . ", to our version of Twitter!</strong></h4>";
   					?>
   				</span>
            </div>
          </div>
        </div>
    </div>

    <div id="make-tweet" class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content white-text">
              <span class="card-title"><h5 style="color:black"><strong>Tweet:</strong></h5></span>
              <br>
          <!-- This is the HTML form that appears in the browser -->
          <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
            <p style="color:black">Recepient: <input type="text" name="country"></p>
            <p style="color:black">Message: <input type="text" name="animal"></p>
            <button class="waves-effect waves-light btn-large" type="submit" name="action" style="background-color:red">Tweet</button>
          </form>
            </div>
          </div>
        </div>
    </div>

    <div id="tweet-history" class="body" class="row">
      <div class="col s12 m6">
        <div class="card white">
          <div class="card-content white-text">
            <span class="card-title"><h5 style="color:black"><strong>Your Tweet History:</strong></h5></span>
            <br>

	<?php

		// open connection
		$connection = mysqli_connect($host, $username, $password) or die ("Unable to connect!");

		// select database
		mysqli_select_db($connection, $dbname) or die ("Unable to select database!");

		// create query
		$query = "SELECT * FROM symbols";
       
		// execute query
		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
		
		// see if any rows were returned
		if (mysqli_num_rows($result) > 0) {

        // print them one after another
        echo "<table cellpadding=10 border=1>";
        while($row = mysqli_fetch_row($result)) {
            echo "<tr>";
            //echo "<td>".$row[0]."</td>";
            echo "<td style='color:black'>" . $row[1]."</td>";
            echo "<td style='color:black'>".$row[2]."</td>";
            echo "<td><a style='color:black' href=".$_SERVER['PHP_SELF']."?id=".$row[0]."><u>Remove Tweet From History</u></a></td>";
            echo "</tr>";
        }
        echo "</table>";

    } else {
			
    		// print status message
    		echo "No rows found!";
		}

		// free result set memory
		mysqli_free_result($connection,$result);

		// set variable values to HTML form inputs
		$country = $_POST['country'];
    	$animal = $_POST['animal'];
		
		// check to see if user has entered anything
		if ($animal != "") {
	 		// build SQL query
			$query = "INSERT INTO symbols (country, animal) VALUES ('$country', '$animal')";
			// run the query
     		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
			// refresh the page to show new update
	 		echo "<meta http-equiv='refresh' content='0'>";
		}
		
		// if DELETE pressed, set an id, if id is set then delete it from DB
		if (isset($_GET['id'])) {

			// create query to delete record
			echo $_SERVER['PHP_SELF'];
    		$query = "DELETE FROM symbols WHERE id = ".$_GET['id'];

			// run the query
     		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
			
			// reset the url to remove id $_GET variable
			$location = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
			echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
			exit;
			
		}
		
		// close connection
		mysqli_close($connection);

	?>

		      </div>
        </div>
      </div>
    </div>

    <footer class="page-footer">
       	<div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Our Version of Twitter</h5>
                <p class="grey-text text-lighten-4">Made by Neel Ismail and Justin Gilbert.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Popular Destinations:</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="https://www.google.ca" target="_blank">Google</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://twitter.com" target="_blank">Twitter</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://www.espn.com" target="_blank">ESPN</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://www.nytimes.com" target="_blank">New York Times</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
              © 2017 Copyright Text
              <a class="grey-text text-lighten-4 right" href="#!"></a>
            </div>
        </div>
    </footer>
    </div>

  <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

	</body>
</html>