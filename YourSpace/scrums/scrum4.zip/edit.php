<!DOCTYPE html>
<html>
	<head>
		<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <title>Profile</title>

    <style>

        .body {
          margin:auto;
          width:70%;
        }

        nav {
          background-color:#ff0000;
          height:130px;
          position:fixed;
          margin-bottom:5px;
          z-index:100;
        }

        .page-footer {
          background-color:#ff0000;
          clear:both;
        }

        #welcome {
          margin-top:125px;
          text-align: center;
        }

        #logo {
          width:100px;
          height:100px;
          margin:15px;
        }

        #box {
          background-color:#fffcfc;
        }

        #make-tweet {
          padding-top:-20px;
        }

        #tweet-history {
          padding-top:-20px;
        }

    </style>
	</head>
	<body>

    <div id="box">

        <nav>
          <div class="nav-wrapper">
            <a href="#" class="brand-logo center"><h1><strong>Twitter</strong></h1></a>
            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li><a href="logout.php">Logout</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><img id="logo" src="twitter-logo-orange.png" /></li>
            </ul>
          </div>
        </nav>
    	
    <br>

    <div id="welcome" class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content white-text">
            	<span class="card-title">
            <?php
						// pass in some info;
						require("common.php"); 
		
						if(empty($_SESSION['user'])) { 
  
							// If they are not, we redirect them to the login page. 
							$location = "http://" . $_SERVER['HTTP_HOST'] . "/login.php";
							echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
							//exit;
         
        					// Remember that this die statement is absolutely critical.  Without it, 
        					// people can view your members-only content without logging in. 
        					die("Redirecting to login.php");
    					}
		
						// To access $_SESSION['user'] values put in an array, show user his username
						$arr = array_values($_SESSION['user']);
						echo "<h4 style='color:black'>Welcome Back, " . $arr[1] . "!</h4>";
   					?>
   				     </span>
            </div>
          </div>
        </div>
    </div>


    <div class="body" class="row">
      <div class="col s12 m6">
          <div class="card white">
              <div class="card-content black-text">
              <span class="card-title"><h5 style="color:black"><strong>Search:</strong></h5></span>
                  <br>
                  <form action="search.php" method="post">
                      <input placeholder="Search for hashtags or tweets by other users..." type="text" name="search">
                      <button class="waves-effect waves-light btn-large" type="submit" name="action" style="background-color:red">Search</button>
                  </form>
              </div>
          </div>
      </div>
    </div>

    <div id="make-tweet" class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content black-text">
              <span class="card-title"><h5 style="color:black"><strong>Tweet:</strong></h5></span>
              <br>
              <!-- This is the HTML form that appears in the browser -->
              <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
              <!--<p style="color:black">Recepient: <input type="text" name="username"></p>-->
              <input placeholder="Tweet a message..." type="text" name="tweet">
              <button class="waves-effect waves-light btn-large" type="submit" name="action" style="background-color:red">Tweet</button>
              </form>
            </div>
          </div>
        </div>
    </div>

    <div id="tweet-history" class="body" class="row">
      <div class="col s12 m6">
        <div class="card white">
          <div class="card-content white-text">
            <span class="card-title"><h5 style="color:black"><strong>Latest Tweets:</strong></h5></span>
            <br>

	<?php

		// open connection
		$connection = mysqli_connect($host, $username, $password) or die ("Unable to connect!");

		// select database
		mysqli_select_db($connection, $dbname) or die ("Unable to select database!");

		// create query
		$query = "SELECT * FROM symbols";
       
		// execute query
		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
		
		// see if any rows were returned
		if (mysqli_num_rows($result) > 0) {

        // print them one after another
        echo "<table cellpadding=10 border=1>";
        while($row = mysqli_fetch_row($result)) {
            echo "<tr>";
            //echo "<td>".$row[0]."</td>";
            echo "<td style='color:black'><strong>" . $row[1]."</strong> tweeted:</td>";
            echo "<td style='color:black'>".$row[2]."</td>";
            echo "<td><a style='color:black' href=".$_SERVER['PHP_SELF']."?id=".$row[0]."><u>Remove Tweet</u></a></td>";
            echo "</tr>";
        }
        echo "</table>";

    } else {
			
    		// print status message
    		echo "No rows found!";
		}

		// free result set memory
		mysqli_free_result($connection,$result);

    function findHashtag($tweet) {
      if (strpos($tweet, '#') !== false) {

        $hashPos = strpos($tweet, '#');
        $hashtag = '';

        while ($tweet[$hashPos] !== ' ' && $hashPos !== strlen($tweet)) {
          $hashtag .= $tweet[$hashPos++];
        }
      return $hashtag;
      }
    }

		// set variable values to HTML form inputs
		$usernm = '@'.$arr[1];
    $tweet = $_POST['tweet'];
    $hashtag = findHashtag($tweet);
		
		// check to see if user has entered anything
		if ($tweet != "") {

	 		// build SQL query
			$query = "INSERT INTO symbols (username, tweet, hashtag) VALUES ('$usernm', '$tweet', '$hashtag')";
			// run the query
     		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
			// refresh the page to show new update
	 		echo "<meta http-equiv='refresh' content='0'>";
		}

		
		// if DELETE pressed, set an id, if id is set then delete it from DB
		if (isset($_GET['id'])) {

			// create query to delete record
			echo $_SERVER['PHP_SELF'];
    		$query = "DELETE FROM symbols WHERE id = ".$_GET['id'];

			// run the query
     		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
			
			// reset the url to remove id $_GET variable
			$location = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
			echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
			exit;
			
		}
		
		// close connection
		mysqli_close($connection);

	?>

		      </div>
        </div>
      </div>
    </div>

    <footer class="page-footer">
       	<div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Our Version of Twitter</h5>
                <p class="grey-text text-lighten-4">Made by Neel Ismail and Justin Gilbert.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Popular Destinations:</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="https://www.google.ca" target="_blank">Google</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://twitter.com" target="_blank">Twitter</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://www.espn.com" target="_blank">ESPN</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://www.nytimes.com" target="_blank">New York Times</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
              © 2017 Copyright Text
              <a class="grey-text text-lighten-4 right" href="#!"></a>
            </div>
        </div>
    </footer>
    </div>

  <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

	</body>
</html>