<!DOCTYPE html>
<html>
	<head>
		<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
		<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <title>Profile</title>

    <style>

        nav {
          background-color:#015a8e;
          height:80px;
          position:fixed;
          margin-bottom:5px;
          z-index:100;
        }

        .body {
          margin:auto;
          width:70%;
        }

        #search {
        	margin-top:75px;
        }

        .tweet-cards {
          margin-top:-15px;
          width:70%;
          margin:auto;
        }

    </style>
	</head>
	<body style="background-color:#fcfcfc">

        <nav>
          <div class="nav-wrapper">
            <a href="edit.php" class="brand-logo center" style="margin-top:-6px"><h3>Twitter</h3></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a href="about.php">About</a></li>
                <li><a href="help.php">Help</a></li>
            </ul>
            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li><a href="edit.php">My Account</a></li>
            </ul>
          </div>
        </nav>
    	
    <br>


    <div id="search" class="body" class="row">
    </div>

	<div id="search-results" class="body" class="row">
    <div class="col s12 m6">
      <div class="card white">
        <div class="card-content black-text">
          <span class="card-title"><strong>Search results for, "<?php echo $_POST["search"] ?>":</strong></span>
        </div>
      </div>
    </div>
  </div>

	<?php

		// pass in some info;
		require("common.php"); 
		
		if(empty($_SESSION['user'])) { 
  
			// If they are not, we redirect them to the login page. 
			$location = "http://" . $_SERVER['HTTP_HOST'] . "/login.php";
			echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
			//exit;
         
        	// Remember that this die statement is absolutely critical.  Without it, 
        	// people can view your members-only content without logging in. 
        	die("Redirecting to login.php"); 
    	}
		
		// To access $_SESSION['user'] values put in an array, show user his username
		$arr = array_values($_SESSION['user']);

		// open connection
		$connection = mysqli_connect($host, $username, $password) or die ("Unable to connect!");

		// select database
		mysqli_select_db($connection, $dbname) or die ("Unable to select database!");

		$search = $_POST["search"];

    // create query
		$query  = "SELECT * FROM symbols WHERE (tweet LIKE '%{$search}%') OR (username LIKE '%{$search}%')";
       
		// execute query
		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());

// see if any rows were returned
    if (mysqli_num_rows($result) > 0) {

        // print them one after another
        while($row = mysqli_fetch_row($result)) {
        echo "<div class='tweet-cards' class='row'>";
        echo "<div class='col s12 m6'>";
          echo "<div class='card white'>";
            echo "<div class='card-content black-text'>";
              echo "<span class='card-title'><p><strong>" . $row[1] . "</strong> tweeted:</p></span>";
                echo "<table>";
                echo "<tr>";
                echo "<td>" . $row[2] . "</td>";
                echo "</tr>";
                echo "</table>";
            echo "</div>";
          echo "</div>";
        echo "</div>";
        echo "</div>";
        }


    } else {
      
        // print status message
        echo "No rows found!";
    }
		
		// close connection
		mysqli_close($connection);

	?>
  
	</body>
</html>