<!DOCTYPE html>
<html>
	<head>
		<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
		<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <title>Profile</title>

    <style>

        nav {
          background-color:#ff0000;
          height:115px;
          position:fixed;
          margin-bottom:5px;
          z-index:100;
        }

        .body {
          margin:auto;
          width:70%;
        }

        .page-footer {
          background-color:#ff0000;
          clear:both;
        }

        #search {
        	margin-top:100px;
        }

        #logo {
          width:80px;
          height:80px;
          margin-right:25px;
          margin-top:10px;
        }

    </style>
	</head>
	<body>

    <div>

        <nav>
          <div class="nav-wrapper">
            <a href="#" class="brand-logo center" style="margin-top:-10px"><h1><strong>Twitter</strong></h1></a>
            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li><a href="edit.php">My Account</a></li>
                <li><a href="logout.php">Logout</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><img id="logo" src="twitter-logo-orange.png" /></li>
            </ul>
          </div>
        </nav>
    	
    <br>


    <div id="search" class="body" class="row">
    </div>

	<div id="search-results" class="body" class="row">
        	<div class="col s12 m6">
          		<div class="card white">
            		<div class="card-content black-text">
            			<span class="card-title"><strong>Search results for, "<?php echo $_POST["search"] ?>":</strong></span>

	<?php

		// pass in some info;
		require("common.php"); 
		
		if(empty($_SESSION['user'])) { 
  
			// If they are not, we redirect them to the login page. 
			$location = "http://" . $_SERVER['HTTP_HOST'] . "/login.php";
			echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
			//exit;
         
        	// Remember that this die statement is absolutely critical.  Without it, 
        	// people can view your members-only content without logging in. 
        	die("Redirecting to login.php"); 
    	}
		
		// To access $_SESSION['user'] values put in an array, show user his username
		$arr = array_values($_SESSION['user']);

		// open connection
		$connection = mysqli_connect($host, $username, $password) or die ("Unable to connect!");

		// select database
		mysqli_select_db($connection, $dbname) or die ("Unable to select database!");

		$search = $_POST["search"];
		$query  = "SELECT * FROM symbols WHERE (tweet LIKE '%{$search}%') OR (username LIKE '%{$search}%')";

		// create query
		//$query = "SELECT * FROM symbols ";
       
		// execute query
		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());

		// see if any rows were returned
		if (mysqli_num_rows($result) > 0) {

        // print them one after another
        echo "<table cellpadding=10 border=1>";
        while($row = mysqli_fetch_row($result)) {
            echo "<tr>";
            //echo "<td>".$row[0]."</td>";
            echo "<td style='color:black'><strong>" . $row[1]."</strong> tweeted:</td>";
            echo "<td style='color:black'>".$row[2]."</td>";
            echo "</tr>";
        }
        echo "</table>";

    } else {
			
    	// print status message
    	echo "No rows found!";
	}
		
		// close connection
		mysqli_close($connection);

	?>
            		</div>
          		</div>
        	</div>
    	</div>

    <footer class="page-footer">
       	<div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Our Version of Twitter</h5>
                <p class="grey-text text-lighten-4">Made by Neel Ismail and Justin Gilbert.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Popular Destinations:</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="https://www.google.ca" target="_blank">Google</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://twitter.com" target="_blank">Twitter</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://www.espn.com" target="_blank">ESPN</a></li>
                  <li><a class="grey-text text-lighten-3" href="https://www.nytimes.com" target="_blank">New York Times</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
              © 2017 Copyright Text
              <a class="grey-text text-lighten-4 right" href="#!"></a>
            </div>
        </div>
    </footer>
    </div>

  	<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  	<script type="text/javascript" src="js/materialize.min.js"></script>
	</body>
</html>